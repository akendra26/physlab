
import {
  useCallback,
  useMemo,
  useState,
} from "react";
import ProjectileCanvas from "./components/ProjectileCanvas";
import type { ProjectileParams } from "./physics/projectile";
import { getProjectileMetrics } from "./physics/projectile";
import "./App.css";

function App() {
  const [speed, setSpeed] = useState(20);
  const [angle, setAngle] = useState(45);
  const [gravity, setGravity] = useState(9.81);
  const [playing, setPlaying] = useState(false);
  const [resetKey, setResetKey] = useState(0);
  const [simulationTime, setSimulationTime] = useState(0);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);

  const params = useMemo<ProjectileParams>(
    () => ({
      speed,
      angleDeg: angle,
      gravity,
    }),
    [speed, angle, gravity]
  );

  const metrics = getProjectileMetrics(params);

  const handleTimeChange = useCallback((time: number) => {
    setSimulationTime(time);
  }, []);

  function resetSimulation() {
    setPlaying(false);
    setSimulationTime(0);
    setResetKey((key) => key + 1);
  }

  return (
    <main className="app">
      <header className="header">
        <div>
          <p className="eyebrow">INTERACTIVE PHYSICS LAB</p>
          <h1>PhysLab<span>.</span></h1>
          <p className="subtitle">
            Explore the physics behind motion.
          </p>
        </div>
        <span className="status">● SYSTEM ONLINE</span>
      </header>

      <section className="panel">
        <h2>Projectile Motion</h2>
        <p className="description">
          Ideal projectile motion without air resistance.
        </p>

        <div className="controls">
          <label>
            <span>Initial speed</span>
            <strong>{speed} m/s</strong>
            <input
              type="range"
              min="0"
              max="50"
              value={speed}
              onChange={(e) => {
                setSpeed(Number(e.target.value));
                resetSimulation();
              }}
            />
          </label>

          <label>
            <span>Launch angle</span>
            <strong>{angle}°</strong>
            <input
              type="range"
              min="0"
              max="90"
              value={angle}
              onChange={(e) => {
                setAngle(Number(e.target.value));
                resetSimulation();
              }}
            />
          </label>

          <label>
            <span>Gravity</span>
            <strong>{gravity.toFixed(2)} m/s²</strong>
            <input
              type="range"
              min="1"
              max="20"
              step="0.01"
              value={gravity}
              onChange={(e) => {
                setGravity(Number(e.target.value));
                resetSimulation();
              }}
            />
          </label>
        </div>
      </section>

      <section className="panel simulation-panel">
        <div className="section-heading">
          <div>
            <h2>Simulation viewport</h2>
            <p className="description">
              Time: {simulationTime.toFixed(2)} s
            </p>
          </div>
        </div>

        <ProjectileCanvas
          params={params}
          playing={playing}
          resetKey={resetKey}
          speedMultiplier={speedMultiplier}
          onTimeChange={handleTimeChange}
        />

        <div className="simulation-controls">
          <button
            onClick={() => {
              if (simulationTime >= metrics.flightTime) {
                setResetKey((key) => key + 1);
                setSimulationTime(0);
              }
              setPlaying((value) => !value);
            }}
          >
            {playing ? "Pause" : "Play"}
          </button>

          <button onClick={resetSimulation}>
            Reset
          </button>

          <label>
            Speed
            <select
              value={speedMultiplier}
              onChange={(e) =>
                setSpeedMultiplier(Number(e.target.value))
              }
            >
              <option value={0.5}>0.5×</option>
              <option value={1}>1×</option>
              <option value={2}>2×</option>
            </select>
          </label>
        </div>
      </section>

      <section className="results">
        <article className="metric">
          <span>Flight time</span>
          <strong>{metrics.flightTime.toFixed(2)} s</strong>
        </article>
        <article className="metric">
          <span>Horizontal range</span>
          <strong>{metrics.range.toFixed(2)} m</strong>
        </article>
        <article className="metric">
          <span>Maximum height</span>
          <strong>{metrics.maxHeight.toFixed(2)} m</strong>
        </article>
      </section>

      <footer>
        <span>PhysLab · Kinematics Module</span>
        <span>SI units · Ideal model</span>
      </footer>
    </main>
  );
}

export default App;

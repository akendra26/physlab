
import { useEffect, useRef } from "react";
import {
  calculateProjectile,
  type ProjectileParams,
} from "../physics/projectile";

type Props = {
  params: ProjectileParams;
  playing: boolean;
  resetKey: number;
  speedMultiplier: number;
  onTimeChange: (time: number) => void;
};

export default function ProjectileCanvas({
  params,
  playing,
  resetKey,
  speedMultiplier,
  onTimeChange,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");

    if (!canvas || !ctx) return;

    const width = canvas.clientWidth;
    const height = 360;
    const dpr = window.devicePixelRatio || 1;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.height = `${height}px`;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const margin = 42;
    const groundY = height - margin;
    const flightTime =
      (2 * params.speed *
        Math.sin((params.angleDeg * Math.PI) / 180)) /
      params.gravity;

    const range =
      params.speed *
      Math.cos((params.angleDeg * Math.PI) / 180) *
      flightTime;

    const maxHeight =
      (params.speed *
        Math.sin((params.angleDeg * Math.PI) / 180)) ** 2 /
      (2 * params.gravity);

    const scaleX =
      (width - 2 * margin) / Math.max(range, 1);

    const scaleY =
      (height - 2 * margin) / Math.max(maxHeight, 1);


    
    function draw(time: number) {
      ctx!.clearRect(0, 0, width, height);

      // Coordinate axes
      ctx!.strokeStyle = "#52627a";
      ctx!.lineWidth = 1;
      ctx!.beginPath();
      ctx!.moveTo(margin, 12);
      ctx!.lineTo(margin, groundY);
      ctx!.lineTo(width - 12, groundY);
      ctx!.stroke();

      // Trajectory
      ctx!.strokeStyle = "#62dfc2";
      ctx!.lineWidth = 2;
      ctx!.beginPath();

      const samples = 120;

      for (let i = 0; i <= samples; i++) {
        const t = (flightTime * i) / samples;
        const s = calculateProjectile(params, t);

        const px = margin + s.x * scaleX;
        const py = groundY - s.y * scaleY;

        if (i === 0) ctx!.moveTo(px, py);
        else ctx!.lineTo(px, py);
      }

      ctx!.stroke();

      // Current projectile position
      const currentTime = Math.min(time, flightTime);
      const state = calculateProjectile(params, currentTime);

      const x = margin + state.x * scaleX;
      const y = groundY - state.y * scaleY;

      ctx!.fillStyle = "#f5b942";
      ctx!.beginPath();
      ctx!.arc(x, y, 7, 0, Math.PI * 2);
      ctx!.fill();

      ctx!.fillStyle = "#cbd5e1";
      ctx!.font = "12px sans-serif";
      ctx!.fillText(`t = ${currentTime.toFixed(2)} s`, margin + 8, 20);
    }

    if (resetKey === 0 && timeRef.current === 0) {
      timeRef.current = 0;
    }

    draw(timeRef.current);

    if (!playing) return;

    let frameId = 0;
    let previousTimestamp: number | null = null;

    function animate(timestamp: number) {
      if (previousTimestamp !== null) {
        const dt = (timestamp - previousTimestamp) / 1000;
        timeRef.current += dt * speedMultiplier;
      }

      previousTimestamp = timestamp;

      if (timeRef.current >= flightTime) {
        timeRef.current = flightTime;
        draw(timeRef.current);
        onTimeChange(timeRef.current);
        return;
      }

      draw(timeRef.current);
      onTimeChange(timeRef.current);

      frameId = requestAnimationFrame(animate);
    }

    frameId = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(frameId);
  }, [
    params,
    playing,
    resetKey,
    speedMultiplier,
    onTimeChange,
  ]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        display: "block",
        width: "100%",
        background: "#0c1625",
        borderRadius: "12px",
      }}
    />
  );
}

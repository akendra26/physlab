export type ProjectileParams = {
  speed: number;
  angleDeg: number;
  gravity: number;
};

export type ProjectileState = {
  t: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
};

export type ProjectileMetrics = {
  flightTime: number;
  range: number;
  maxHeight: number;
};

export function calculateProjectile(
  p: ProjectileParams,
  t: number
): ProjectileState {
  if (
    !Number.isFinite(p.speed) ||
    !Number.isFinite(p.angleDeg) ||
    !Number.isFinite(p.gravity) ||
    p.speed < 0 ||
    p.angleDeg < 0 ||
    p.angleDeg > 90 ||
    p.gravity <= 0 ||
    !Number.isFinite(t) ||
    t < 0
  ) {
    throw new Error("Invalid projectile parameters or time");
  }

  const theta = p.angleDeg * Math.PI / 180;
  const vx0 = p.speed * Math.cos(theta);
  const vy0 = p.speed * Math.sin(theta);

  return {
    t,
    x: vx0 * t,
    y: vy0 * t - 0.5 * p.gravity * t * t,
    vx: vx0,
    vy: vy0 - p.gravity * t,
  };
}

export function getProjectileMetrics(
  p: ProjectileParams
): ProjectileMetrics {
  const theta = p.angleDeg * Math.PI / 180;
  const vx0 = p.speed * Math.cos(theta);
  const vy0 = p.speed * Math.sin(theta);

  if (
    ![p.speed, p.angleDeg, p.gravity].every(Number.isFinite) ||
    p.speed < 0 ||
    p.angleDeg < 0 ||
    p.angleDeg > 90 ||
    p.gravity <= 0
  ) {
    throw new Error("Invalid projectile parameters");
  }

  const flightTime = 2 * vy0 / p.gravity;

  return {
    flightTime,
    range: vx0 * flightTime,
    maxHeight: vy0 * vy0 / (2 * p.gravity),
  };
}
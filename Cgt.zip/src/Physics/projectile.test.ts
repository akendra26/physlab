import { describe, expect, it } from "vitest";
import {
  calculateProjectile,
  getProjectileMetrics,
} from "./projectile";

const params = {
  speed: 20,
  angleDeg: 45,
  gravity: 9.81,
};

describe("Projectile motion", () => {
  it("starts at the origin", () => {
    const state = calculateProjectile(params, 0);

    expect(state.x).toBeCloseTo(0);
    expect(state.y).toBeCloseTo(0);
  });

  it("calculates flight time, range, and height", () => {
    const result = getProjectileMetrics(params);

    expect(result.flightTime).toBeCloseTo(2.88, 2);
    expect(result.range).toBeCloseTo(40.77, 1);
    expect(result.maxHeight).toBeCloseTo(10.19, 1);
  });

  it("returns to its starting height", () => {
    const result = getProjectileMetrics(params);
    const state = calculateProjectile(
      params,
      result.flightTime
    );

    expect(state.y).toBeCloseTo(0);
  });
});